#include<iostream>
#include<fstream>
#include<cstring>
#include<utility>
#include"character.h"
using namespace std;

char ciphertext[1000];
character sword[26];
void decCaesar(char cFile[], char pFile[]);
void ord(character a[], int b);
void selectionSort(character arr[], int n);
void swap(character *xp, character *yp);

int main() {


	decCaesar("cipherFile.txt", "replainFile.txt");

	return 0;
}

void decCaesar(char cFile[], char pFile[]) {
	ifstream fin;
	ofstream fout;

	char c;
	int count = 0, i = 0;
	fout.open(pFile);

	while (i < 26)
	{
		fin.open(cFile);
		while (!fin.eof()) {

			fin.get(c);
			if (c == static_cast<char>(97+i))
				sword[i].count++;
			if (c != ' ')
				count++;


		}
		fin.close();
		sword[i].frequency = sword[i].count / (count*1.0);
		i++;
		count = 0;
	}
	for (int x = 0; x < 26; x++) {
	       sword[x].order = x;
	}
		selectionSort(sword, 26);

		ord(sword, 26);	

		char ci;
		fin.open(cFile);
		while (!fin.eof()) {

			fin.get(c);

				for (int j = 0; j < 26; j++) {
					if (c == ' ')
						ci = c;
					else if (c == static_cast<char>(97 + sword[j].order))
						ci = sword[j].cipher;
					

				}
				fout << ci;
		}
		fin.close();
		fout.close();
}

void swap(character *xp, character *yp)
{
	character temp = *xp;
	*xp = *yp;
	*yp = temp;
}
void selectionSort(character arr[], int n)
{
	int i, j, maxindex;

	for (i = 0; i < n - 1; i++)
	{
		maxindex = i;
		for (j = i + 1; j < n; j++)
			if (arr[j].frequency > arr[maxindex].frequency)
				maxindex = j;

		swap(&arr[maxindex], &arr[i]);
	}
}
void ord(character a[], int b) {

			a[0].cipher = 'E';
			a[1].cipher = 'T';
			a[2].cipher = 'A';
			a[3].cipher = 'N';
			a[4].cipher = 'O';
			a[5].cipher = 'I';
			a[6].cipher = 'S';
			a[7].cipher = 'H';
			a[8].cipher = 'R';
			a[9].cipher = 'D';
			a[10].cipher = 'L';
			a[11].cipher = 'C';
			a[12].cipher = 'F';
			a[13].cipher = 'M';
			a[14].cipher = 'P';
			a[15].cipher = 'U';
			a[16].cipher = 'Y';
			a[17].cipher = 'B';
			a[18].cipher = 'G';
			a[19].cipher = 'K';
			a[20].cipher = 'X';
			a[21].cipher = 'W';
			a[22].cipher = 'V';
			a[23].cipher = 'Z';
			a[24].cipher = 'Q';
			a[25].cipher = 'J';
	}

