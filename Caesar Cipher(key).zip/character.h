#pragma once
class character {
public:
	char cipher;
	int count;
	double frequency;
	int order;
};