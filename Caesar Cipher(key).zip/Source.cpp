#include<iostream>
#include<fstream>
#include<cstring>
#include<utility>
#include"character.h"
using namespace std;

char ciphertext[1000];
character sword[26];
char letter[26];
char letterup[26];
void decCaesar(char cFile[], char pFile[]);
int getkey(character a[], int b);
void selectionSort(character arr[], int n);
void swap(character *xp, character *yp);

int main() {

	for (int i = 0; i < 26; i++)
		letter[i] = static_cast<char>(i + 97);
	for (int i = 0; i < 26; i++)
		letterup[i] = static_cast<char>(i + 65);

	decCaesar("cipherFile.txt", "replainFile.txt");

	return 0;
}

void decCaesar(char cFile[], char pFile[]) {
	ifstream fin;
	ofstream fout;

	char c;
	int count = 0, i = 0;
	fout.open(pFile);

	while (i < 26)
	{
		fin.open(cFile);
		while (!fin.eof()) {

			fin.get(c);
			if (c == static_cast<char>(97 + i))
				sword[i].count++;
			if (c != ' ')
				count++;


		}
		fin.close();
		sword[i].frequency = sword[i].count / (count*1.0);
		i++;
		count = 0;
	}
	for (int x = 0; x < 26; x++) {
		sword[x].order = x;
	}
	selectionSort(sword, 26);
	for (int q = 0; q < 26; q++) {
	fout << static_cast<char>(97 + sword[q].order) << "  " << sword[q].frequency << endl;
	}
	char ci;
	fin.open(cFile);
	fout << getkey(sword, 26) << endl;
	while (!fin.eof()) {

		fin.get(c);
		for (int j = 0; j < 26; j++) {
			if (c == ' ')
					ci = c;
				else if (c == letter[j])
					ci = letterup[(j + 26 - getkey(sword,26)) % 26];
				else if (c<'a' || c>'z')
					ci = c;
			}
			fout << ci;

		}
	
	fin.close();
	fout.close();
}

void swap(character *xp, character *yp)
{
	character temp = *xp;
	*xp = *yp;
	*yp = temp;
}
void selectionSort(character arr[], int n)
{
	int i, j, maxindex;

	for (i = 0; i < n - 1; i++)
	{
		maxindex = i;
		for (j = i + 1; j < n; j++)
			if (arr[j].frequency > arr[maxindex].frequency)
				maxindex = j;

		swap(&arr[maxindex], &arr[i]);
	}
}
int  getkey(character a[], int b) {
	int key = 0, plain = 0, cipher = 0;
	bool find = false;
	a[0].cipher = 'e';

	for (int x = 0; x < b; x++) {
		if (letter[x] == a[0].cipher) {
			plain = x;
			break;
		}
	}
	while (!find)
	{

		if (letter[(plain + key) % 26] == static_cast<char>(97 + a[0].order))
			find = true;
		else
			key++;
	}
	return key;
}